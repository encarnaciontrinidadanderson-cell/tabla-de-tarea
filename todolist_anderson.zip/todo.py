
import sqlite3
import typer

app = typer.Typer()

def get_db_connection():
    conn = sqlite3.connect("todo.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.command()
def create(task: str):
    conn = get_db_connection()
    conn.execute("INSERT INTO tasks (task, done) VALUES (?, ?)", (task, False))
    conn.commit()
    conn.close()
    typer.echo(f"Tarea creada: {task}")

@app.command()
def list():
    conn = get_db_connection()
    tasks = conn.execute("SELECT id, task, done FROM tasks").fetchall()
    conn.close()
    if not tasks:
        typer.echo("No hay tareas registradas.")
        return
    for task in tasks:
        status = "✅" if task["done"] else "❌"
        typer.echo(f"{task['id']}. {task['task']} - {status}")

@app.command()
def update(task_id: int, task: str = None, done: bool = None):
    conn = get_db_connection()
    cursor = conn.cursor()
    current = cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    if not current:
        typer.echo("❌ No se encontró la tarea con ese ID.")
        return
    new_task = task if task is not None else current["task"]
    new_done = done if done is not None else current["done"]
    cursor.execute("UPDATE tasks SET task = ?, done = ? WHERE id = ?", (new_task, new_done, task_id))
    conn.commit()
    conn.close()
    typer.echo(f"✅ Tarea actualizada correctamente (ID: {task_id}).")

@app.command()
def delete(task_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
    if not cursor.fetchone():
        typer.echo("❌ No se encontró la tarea con ese ID.")
        return
    cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    conn.commit()
    conn.close()
    typer.echo(f"🗑️ Tarea eliminada correctamente (ID: {task_id}).")

if __name__ == "__main__":
    app()
